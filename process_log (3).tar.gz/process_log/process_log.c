#include <stdlib.h>
#include <unistd.h>
#include "process_log.h"

int get_proc_log_level()
{
	int proc_log_level = -1;
	proc_log_level = syscall(435);
	return proc_log_level;
}

int set_proc_log_level(int new_level)
{
	int check_success = -1;
	check_success = syscall(436, new_level);
	return check_success;
}

int proc_log_message(int level, char* message)
{
	int check_success = -1;
	check_success = syscall(437, message, level);
	return check_success;
}

int* retrieve_set_level_params(int new_level)
{
	int* set_level_params_pointer;
	set_level_params_pointer = (int*)malloc(3 * sizeof(int));
	set_level_params_pointer[0] = 436;
	set_level_params_pointer[1] = 1;
	set_level_params_pointer[2] = new_level;
	return set_level_params_pointer;
}

int* retrieve_get_level_params()
{
	int* get_level_params_pointer;
	get_level_params_pointer = (int*)malloc(2 * sizeof(int));
	get_level_params_pointer[0] = 435;
	get_level_params_pointer[1] = 0;
	return get_level_params_pointer;
}

int interpret_set_level_result(int ret_value)
{
	return ret_value;
}

int interpret_get_level_result(int ret_value)
{
	return ret_value;
}

int interpret_log_message_result(int ret_value)
{
	return ret_value;
}
